from typing import List

class User:
   subscription: bool

def notify(user: User) -> None:
   pass

def get_notify_users(users: List[User]) -> List[User]:
  #Filter active User
  return [user for user in  users if user.subscription]

def notify_active_users(users: List[User]) -> None:
    """Send an notification to a given list of users.
    """
    for user in get_notify_users(users):
        notify(user)
