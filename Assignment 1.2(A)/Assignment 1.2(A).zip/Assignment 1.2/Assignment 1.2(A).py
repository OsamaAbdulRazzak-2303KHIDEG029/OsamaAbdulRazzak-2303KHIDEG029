from dataclasses import dataclass

@ dataclass
class mount:
    Mountain_name : str
    Elevation : int 

# Now creating instance of class
mountain = mount('Godwin Austen', 8611)
print(mountain)
# Checking the type of variable
print(type(mountain))
# Converting it into string
mountain = str(mountain)
print(mountain)
# Checking type of variable
print(type(mountain))

